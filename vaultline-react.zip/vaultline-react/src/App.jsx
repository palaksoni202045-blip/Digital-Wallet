import { useEffect, useRef, useState } from 'react';
import Login from './components/Login.jsx';
import Sidebar from './components/Sidebar.jsx';
import Dashboard from './components/Dashboard.jsx';
import SendMoney from './components/SendMoney.jsx';
import RequestAdd from './components/RequestAdd.jsx';
import Receive from './components/Receive.jsx';
import ScanPay from './components/ScanPay.jsx';
import SplitBill from './components/SplitBill.jsx';
import Cards from './components/Cards.jsx';
import Transactions from './components/Transactions.jsx';
import Profile from './components/Profile.jsx';
import ToastEl from './components/Toast.jsx';
import { initialContacts, initialCards, seedTransactions, newCardBrands } from './data/seed.js';
import { fmtMoney } from './utils.js';

export default function App() {
  const [loggedIn, setLoggedIn] = useState(false);
  const [view, setView] = useState('dashboard');
  const [requestTab, setRequestTab] = useState('add');

  const [balance, setBalance] = useState(4231.87);
  const [contacts] = useState(initialContacts);
  const [cards, setCards] = useState(initialCards);
  const [transactions, setTransactions] = useState(seedTransactions());
  const [splits, setSplits] = useState([]);

  const [toastMsg, setToastMsg] = useState('');
  const [toastVisible, setToastVisible] = useState(false);
  const toastTimer = useRef(null);

  function toast(msg) {
    setToastMsg(msg);
    setToastVisible(true);
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToastVisible(false), 2600);
  }

  function navigate(nextView, subtab) {
    setView(nextView);
    if (nextView === 'request' && subtab) setRequestTab(subtab);
  }

  function addTransaction(tx) {
    setTransactions((prev) => [{ id: 'tx' + Date.now() + Math.random(), date: new Date(), ...tx }, ...prev]);
  }

  function handleSend(contact, amount, note) {
    setBalance((b) => b - amount);
    addTransaction({ name: contact.name, type: 'out', amount, note, icon: '👤' });
    toast(`Sent $${fmtMoney(amount)} to ${contact.name.split(' ')[0]}`);
    navigate('dashboard');
  }

  function handleAddMoney(card, amount) {
    setBalance((b) => b + amount);
    addTransaction({ name: `Top-up · ${card.issuer}`, type: 'in', amount, note: 'Card top-up', icon: '💳' });
    toast(`Added $${fmtMoney(amount)} to your balance`);
    navigate('dashboard');
  }

  function handleRequest(contact, amount) {
    toast(`Request for $${fmtMoney(amount)} sent to ${contact.name.split(' ')[0]}`);
  }

  function handleSimulateIncoming(amountOverride) {
    const amount = amountOverride || Math.round(Math.random() * 8000) / 100 + 5;
    const payer = contacts[Math.floor(Math.random() * contacts.length)];
    setBalance((b) => b + amount);
    addTransaction({ name: payer.name, type: 'in', amount, note: 'Scanned your code', icon: '📥' });
    toast(`${payer.name.split(' ')[0]} paid you $${fmtMoney(amount)}`);
  }

  function handleConfirmScanPay(to, amount) {
    setBalance((b) => b - amount);
    addTransaction({ name: to, type: 'out', amount, note: 'Paid via scan', icon: '📷' });
    toast(`Paid $${fmtMoney(amount)} to ${to}`);
    navigate('dashboard');
  }

  function handleCreateSplit(desc, total, shares) {
    setSplits((prev) => [{ id: 'split' + Date.now(), desc, total, date: new Date(), shares }, ...prev]);
    toast(`Split "${desc}" sent to ${shares.length} ${shares.length === 1 ? 'person' : 'people'}`);
  }

  function handleSettleSplit(splitId, contactId) {
    let settledShare = null;
    setSplits((prev) =>
      prev.map((split) => {
        if (split.id !== splitId) return split;
        return {
          ...split,
          shares: split.shares.map((s) => {
            if (s.contactId === contactId && !s.settled) {
              settledShare = s;
              return { ...s, settled: true };
            }
            return s;
          }),
        };
      })
    );
    if (settledShare) {
      const contact = contacts.find((c) => c.id === contactId);
      setBalance((b) => b + settledShare.amount);
      addTransaction({ name: contact.name, type: 'in', amount: settledShare.amount, note: `Settled: ${splits.find((s) => s.id === splitId)?.desc || ''}`, icon: '🤝' });
      toast(`${contact.name.split(' ')[0]} settled $${fmtMoney(settledShare.amount)}`);
    }
  }

  function handleToggleFreeze(id) {
    setCards((prev) => prev.map((c) => (c.id === id ? { ...c, frozen: !c.frozen } : c)));
    const card = cards.find((c) => c.id === id);
    if (card) toast(!card.frozen ? `${card.issuer} frozen` : `${card.issuer} unfrozen`);
  }

  function handleRemoveCard(id) {
    setCards((prev) => prev.filter((c) => c.id !== id));
    toast('Card removed');
  }

  function handleAddCard() {
    const idx = cards.length % newCardBrands.length;
    const brand = newCardBrands[idx];
    const last4 = String(Math.floor(1000 + Math.random() * 9000));
    setCards((prev) => [
      ...prev,
      { id: 'card' + Date.now(), issuer: brand.issuer, last4, holder: 'AARAV KAPOOR', expiry: '11/29', frozen: false, gradient: brand.gradient },
    ]);
    toast('New card added');
  }

  function handleLogin() {
    setLoggedIn(true);
    toast('Welcome back, Aarav');
  }

  function handleLogout() {
    setLoggedIn(false);
    setView('dashboard');
  }

  useEffect(() => {
    document.title = 'Vaultline — Digital Wallet';
  }, []);

  if (!loggedIn) {
    return <Login onLogin={handleLogin} />;
  }

  return (
    <>
      <Sidebar activeView={view} onNavigate={navigate} onLogout={handleLogout} />
      <main className="main">
        {view === 'dashboard' && (
          <Dashboard balance={balance} cards={cards} transactions={transactions} onNavigate={navigate} />
        )}
        {view === 'send' && (
          <SendMoney contacts={contacts} balance={balance} onSend={{ send: handleSend, toast }} />
        )}
        {view === 'request' && (
          <RequestAdd
            cards={cards}
            contacts={contacts}
            initialTab={requestTab}
            onAddMoney={handleAddMoney}
            onRequest={handleRequest}
            toast={toast}
          />
        )}
        {view === 'receive' && (
          <Receive onSimulateIncoming={handleSimulateIncoming} toast={toast} />
        )}
        {view === 'scan' && (
          <ScanPay balance={balance} onConfirmPay={handleConfirmScanPay} toast={toast} />
        )}
        {view === 'split' && (
          <SplitBill
            contacts={contacts}
            splits={splits}
            onCreateSplit={handleCreateSplit}
            onSettleSplit={handleSettleSplit}
            toast={toast}
          />
        )}
        {view === 'cards' && (
          <Cards cards={cards} onAddCard={handleAddCard} onToggleFreeze={handleToggleFreeze} onRemoveCard={handleRemoveCard} />
        )}
        {view === 'transactions' && <Transactions transactions={transactions} />}
        {view === 'profile' && <Profile onLogout={handleLogout} />}
      </main>
      <ToastEl message={toastMsg} visible={toastVisible} />
    </>
  );
}
