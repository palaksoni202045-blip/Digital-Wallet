import { useEffect, useRef, useState } from 'react';

export default function ScanPay({ balance, onConfirmPay, toast }) {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const streamRef = useRef(null);
  const rafRef = useRef(null);

  const [status, setStatus] = useState('Camera not started yet.');
  const [scanning, setScanning] = useState(false);
  const [manualInput, setManualInput] = useState('');
  const [result, setResult] = useState(null); // { to, amount }

  useEffect(() => () => stopScanner(), []); // cleanup on unmount

  function handleScannedPayload(raw) {
    let to = 'Unknown recipient';
    let amount = '';
    try {
      const parsed = JSON.parse(raw);
      to = parsed.to || to;
      amount = parsed.amount || '';
    } catch {
      to = raw.slice(0, 40);
    }
    setResult({ to, amount });
    setStatus('Code recognized — confirm the payment below.');
    toast('Code scanned');
  }

  async function toggleScanner() {
    if (streamRef.current) { stopScanner(); return; }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
      streamRef.current = stream;
      const video = videoRef.current;
      video.srcObject = stream;
      await video.play();
      setScanning(true);
      setStatus('Point your camera at a Vaultline code.');
      scanLoop();
    } catch {
      setStatus('Camera unavailable in this browser/context — try "Simulate a scan" or paste a code below.');
    }
  }

  function stopScanner() {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    if (rafRef.current) cancelAnimationFrame(rafRef.current);
    setScanning(false);
    setStatus((s) => (s.startsWith('Camera unavailable') ? s : 'Camera stopped.'));
  }

  function scanLoop() {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!streamRef.current) return;
    if (video.readyState === video.HAVE_ENOUGH_DATA && typeof window.jsQR !== 'undefined') {
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const code = window.jsQR(imgData.data, imgData.width, imgData.height);
      if (code && code.data) {
        handleScannedPayload(code.data);
        stopScanner();
        return;
      }
    }
    rafRef.current = requestAnimationFrame(scanLoop);
  }

  function simulateScan() {
    const demo = JSON.stringify({ type: 'pay', to: 'VL-5521-MS', amount: 32.5, note: 'Meera Shah — coffee' });
    handleScannedPayload(demo);
  }

  function processManualScan() {
    if (!manualInput.trim()) { toast('Paste a code first'); return; }
    handleScannedPayload(manualInput.trim());
  }

  function confirmPayment() {
    const amt = parseFloat(result.amount);
    if (!amt || amt <= 0) { toast('Enter a valid amount'); return; }
    if (amt > balance) { toast('Insufficient balance'); return; }
    onConfirmPay(result.to, amt);
    setResult(null);
    setManualInput('');
  }

  return (
    <section className="view active">
      <div className="topbar"><div><h1>Scan &amp; pay</h1><p>Scan someone&apos;s receive code to pay them instantly.</p></div></div>
      <div className="panel" style={{ maxWidth: 460 }}>
        <div className="scanner-frame">
          <video ref={videoRef} playsInline muted></video>
          <canvas ref={canvasRef} style={{ display: 'none' }}></canvas>
          <div className="scanner-reticle"></div>
        </div>
        <p className="scanner-status">{status}</p>
        <div style={{ display: 'flex', gap: 10, marginTop: 14 }}>
          <button className="btn btn-brass btn-block" onClick={toggleScanner}>{scanning ? 'Stop camera' : 'Start camera'}</button>
          <button className="btn btn-ghost btn-block" onClick={simulateScan}>Simulate a scan</button>
        </div>
        <div className="field" style={{ marginTop: 18 }}>
          <label>Or paste a code manually</label>
          <input
            type="text"
            placeholder='e.g. {"to":"VL-8842-AK","amount":25}'
            value={manualInput}
            onChange={(e) => setManualInput(e.target.value)}
          />
        </div>
        <button className="btn btn-ghost btn-block" onClick={processManualScan}>Use this code</button>
      </div>

      {result && (
        <div className="panel" style={{ maxWidth: 460, marginTop: 18 }}>
          <div className="section-head" style={{ marginBottom: 14 }}><h2>Confirm payment</h2></div>
          <div className="field">
            <label>Paying</label>
            <input type="text" value={result.to} disabled readOnly />
          </div>
          <div className="field">
            <label>Amount</label>
            <div className="amount-input">
              <span>$</span>
              <input
                type="number" min="0" step="0.01"
                value={result.amount}
                onChange={(e) => setResult({ ...result, amount: e.target.value })}
              />
            </div>
          </div>
          <button className="btn btn-brass btn-block" onClick={confirmPayment}>Confirm &amp; pay</button>
        </div>
      )}
    </section>
  );
}
