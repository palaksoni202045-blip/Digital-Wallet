import { useState } from 'react';
import LedgerRow from './LedgerRow.jsx';

export default function Transactions({ transactions }) {
  const [filter, setFilter] = useState('all');
  const [query, setQuery] = useState('');

  const q = query.toLowerCase();
  const list = transactions.filter((t) => {
    if (filter === 'in' && t.type !== 'in') return false;
    if (filter === 'out' && t.type !== 'out') return false;
    if (q && !t.name.toLowerCase().includes(q) && !t.note.toLowerCase().includes(q)) return false;
    return true;
  });

  return (
    <section className="view active">
      <div className="topbar"><div><h1>Transaction ledger</h1><p>Every credit and debit on your wallet.</p></div></div>
      <div className="filter-bar">
        <button className={`chip-filter${filter === 'all' ? ' active' : ''}`} onClick={() => setFilter('all')}>All</button>
        <button className={`chip-filter${filter === 'in' ? ' active' : ''}`} onClick={() => setFilter('in')}>Money in</button>
        <button className={`chip-filter${filter === 'out' ? ' active' : ''}`} onClick={() => setFilter('out')}>Money out</button>
        <input
          type="text" className="search-input" placeholder="Search transactions"
          value={query} onChange={(e) => setQuery(e.target.value)}
        />
      </div>
      <div className="ledger">
        {list.map((t) => <LedgerRow key={t.id} t={t} />)}
        {list.length === 0 && <div className="empty-state">Nothing matches that filter.</div>}
      </div>
    </section>
  );
}
