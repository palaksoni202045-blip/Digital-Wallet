import { useState } from 'react';

export default function Login({ onLogin }) {
  const [email, setEmail] = useState('aarav.kapoor@email.com');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  function submit() {
    if (!email.trim() || !password) {
      setError('Enter both email and password to continue.');
      return;
    }
    setError('');
    setPassword('');
    onLogin();
  }

  function onKeyDown(e) {
    if (e.key === 'Enter') submit();
  }

  return (
    <div className="login-screen">
      <div className="login-card">
        <div className="login-brand">
          <div className="brand-mark">V</div>
          <div className="brand-name">Vaultline</div>
        </div>
        <p className="login-tagline">Log in to your wallet</p>
        <div className="field">
          <label>Email</label>
          <input
            type="email"
            placeholder="you@email.com"
            autoComplete="username"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            onKeyDown={onKeyDown}
          />
        </div>
        <div className="field" style={{ marginBottom: 6 }}>
          <label>Password</label>
          <input
            type="password"
            placeholder="••••••••"
            autoComplete="current-password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            onKeyDown={onKeyDown}
          />
        </div>
        <p className="login-error">{error}</p>
        <button className="btn btn-brass btn-block" onClick={submit}>Log in</button>
        <p className="login-hint">Demo account — enter any password to continue</p>
      </div>
    </div>
  );
}
