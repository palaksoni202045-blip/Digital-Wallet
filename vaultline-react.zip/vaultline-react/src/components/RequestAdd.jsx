import { useEffect, useState } from 'react';
import QrBox from './QrBox.jsx';
import { WALLET_ID } from '../data/seed.js';

export default function RequestAdd({ cards, contacts, initialTab, onAddMoney, onRequest, toast }) {
  const [tab, setTab] = useState(initialTab || 'add');
  const [source, setSource] = useState(cards[0]?.id || '');
  const [addAmount, setAddAmount] = useState('');
  const [requestAmount, setRequestAmount] = useState('');
  const [requestFrom, setRequestFrom] = useState(contacts[0]?.id || '');

  useEffect(() => {
    if (!source && cards.length) setSource(cards[0].id);
  }, [cards, source]);

  function submitAdd() {
    const amt = parseFloat(addAmount);
    const card = cards.find((c) => c.id === source);
    if (!amt || amt <= 0) { toast('Enter a valid amount'); return; }
    if (!card) { toast('Add a card first'); return; }
    onAddMoney(card, amt);
    setAddAmount('');
  }

  function submitRequest() {
    const amt = parseFloat(requestAmount);
    const contact = contacts.find((c) => c.id === requestFrom);
    if (!amt || amt <= 0) { toast('Enter a valid amount'); return; }
    onRequest(contact, amt);
    setRequestAmount('');
  }

  const requestPayload = JSON.stringify({
    type: 'request',
    to: WALLET_ID,
    amount: parseFloat(requestAmount) || undefined,
    note: 'Payment request',
  });

  return (
    <section className="view active">
      <div className="topbar"><div><h1>Request &amp; add money</h1><p>Pull funds from a linked card or request from someone.</p></div></div>
      <div className="filter-bar">
        <button className={`chip-filter${tab === 'add' ? ' active' : ''}`} onClick={() => setTab('add')}>Add money</button>
        <button className={`chip-filter${tab === 'request' ? ' active' : ''}`} onClick={() => setTab('request')}>Request money</button>
      </div>

      {tab === 'add' && (
        <div className="panel">
          <div className="field">
            <label>Funding source</label>
            <select value={source} onChange={(e) => setSource(e.target.value)}>
              {cards.map((c) => (
                <option key={c.id} value={c.id} disabled={c.frozen}>
                  {c.issuer} •••• {c.last4}{c.frozen ? ' (frozen)' : ''}
                </option>
              ))}
            </select>
          </div>
          <div className="field">
            <label>Amount</label>
            <div className="amount-input">
              <span>$</span>
              <input type="number" min="0" step="0.01" placeholder="0.00" value={addAmount} onChange={(e) => setAddAmount(e.target.value)} />
            </div>
          </div>
          <button className="btn btn-brass btn-block" onClick={submitAdd}>Add to balance</button>
        </div>
      )}

      {tab === 'request' && (
        <div className="panel">
          <QrBox payload={requestPayload} />
          <div className="field">
            <label>Amount to request</label>
            <div className="amount-input">
              <span>$</span>
              <input type="number" min="0" step="0.01" placeholder="0.00" value={requestAmount} onChange={(e) => setRequestAmount(e.target.value)} />
            </div>
          </div>
          <div className="field">
            <label>From</label>
            <select value={requestFrom} onChange={(e) => setRequestFrom(e.target.value)}>
              {contacts.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </div>
          <button className="btn btn-brass btn-block" onClick={submitRequest}>Send request</button>
        </div>
      )}
    </section>
  );
}
