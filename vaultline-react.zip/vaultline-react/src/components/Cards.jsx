import WalletCard from './WalletCard.jsx';
import { PlusIcon } from './Icons.jsx';

export default function Cards({ cards, onAddCard, onToggleFreeze, onRemoveCard }) {
  return (
    <section className="view active">
      <div className="topbar">
        <div><h1>Your cards</h1><p>Manage linked and virtual cards.</p></div>
        <button className="btn btn-brass" onClick={onAddCard}>+ Add card</button>
      </div>
      <div className="card-row" style={{ flexWrap: 'wrap' }}>
        {cards.map((c) => (
          <div key={c.id}>
            <WalletCard card={c} />
            <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
              <button className="btn btn-ghost btn-sm" onClick={() => onToggleFreeze(c.id)}>{c.frozen ? 'Unfreeze' : 'Freeze'}</button>
              <button className="btn btn-ghost btn-sm" onClick={() => onRemoveCard(c.id)}>Remove</button>
            </div>
          </div>
        ))}
        <div className="wallet-card add-card" onClick={onAddCard}>
          <PlusIcon />
          Add a card
        </div>
      </div>
    </section>
  );
}
