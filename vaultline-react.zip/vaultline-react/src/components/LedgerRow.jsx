import { fmtMoney, fmtDate } from '../utils.js';

export default function LedgerRow({ t }) {
  const sign = t.type === 'in' ? '+' : '−';
  const cls = t.type === 'in' ? 'pos' : 'neg';
  const bg = t.type === 'in' ? 'rgba(76,140,134,0.18)' : 'rgba(217,117,117,0.18)';
  const color = t.type === 'in' ? 'var(--teal)' : 'var(--coral)';
  return (
    <div className="ledger-row">
      <div className="tx-icon" style={{ background: bg, color }}>{t.icon}</div>
      <div className="tx-main">
        <div className="tx-name">{t.name}</div>
        <div className="tx-meta">{t.note} · {fmtDate(t.date)}</div>
      </div>
      <div className="tx-leader"></div>
      <div className={`tx-amount ${cls}`}>{sign}${fmtMoney(t.amount)}</div>
    </div>
  );
}
