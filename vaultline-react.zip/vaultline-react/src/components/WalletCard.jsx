export default function WalletCard({ card }) {
  return (
    <div className={`wallet-card${card.frozen ? ' frozen' : ''}`} style={{ background: card.gradient }}>
      {card.frozen && <div className="frozen-badge">Frozen</div>}
      <div className="card-brand-row">
        <div className="card-issuer">{card.issuer}</div>
        <div className="chip"></div>
      </div>
      <div className="card-number">•••• •••• •••• {card.last4}</div>
      <div className="card-foot">
        <div className="card-holder">{card.holder}</div>
        <div className="card-expiry">{card.expiry}</div>
      </div>
    </div>
  );
}
