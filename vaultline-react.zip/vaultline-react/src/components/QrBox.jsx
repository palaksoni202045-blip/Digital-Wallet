import { useEffect, useRef } from 'react';

export default function QrBox({ payload, size = 176, style }) {
  const ref = useRef(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    el.innerHTML = '';
    if (typeof window.QRCode === 'undefined') {
      el.innerHTML = `<div style="font-size:11px;color:#666;padding:10px;text-align:center;">QR library unavailable — code: ${payload}</div>`;
      return;
    }
    // eslint-disable-next-line no-new
    new window.QRCode(el, {
      text: payload,
      width: size,
      height: size,
      colorDark: '#14171F',
      colorLight: '#EDE6D6',
      correctLevel: window.QRCode.CorrectLevel.M,
    });
  }, [payload, size]);

  return <div className="request-qr" ref={ref} style={style}></div>;
}
