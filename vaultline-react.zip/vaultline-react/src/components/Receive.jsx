import { useState } from 'react';
import QrBox from './QrBox.jsx';
import { WALLET_ID } from '../data/seed.js';
import { ClockIcon, ShieldIcon } from './Icons.jsx';

export default function Receive({ onSimulateIncoming, toast }) {
  const [amount, setAmount] = useState('');

  function copyWalletId() {
    navigator.clipboard?.writeText(WALLET_ID).catch(() => {});
    toast('Wallet ID copied');
  }

  const payload = JSON.stringify({ type: 'pay', to: WALLET_ID, amount: parseFloat(amount) || undefined });

  return (
    <section className="view active">
      <div className="topbar"><div><h1>Receive money</h1><p>Share your code so anyone can pay you directly.</p></div></div>
      <div className="dash-grid">
        <div className="panel" style={{ maxWidth: '100%' }}>
          <div style={{ textAlign: 'center' }}>
            <QrBox payload={payload} size={200} style={{ width: 200, height: 200 }} />
            <div className="wallet-id-tag">{WALLET_ID}</div>
          </div>
          <div className="field" style={{ marginTop: 22 }}>
            <label>Request a specific amount (optional)</label>
            <div className="amount-input">
              <span>$</span>
              <input type="number" min="0" step="0.01" placeholder="0.00" value={amount} onChange={(e) => setAmount(e.target.value)} />
            </div>
          </div>
          <div style={{ display: 'flex', gap: 10 }}>
            <button className="btn btn-ghost btn-block" onClick={copyWalletId}>Copy wallet ID</button>
            <button className="btn btn-brass btn-block" onClick={() => onSimulateIncoming(parseFloat(amount) || null)}>Simulate incoming payment</button>
          </div>
        </div>
        <div className="quick-actions">
          <div className="qa-card">
            <div className="qa-icon" style={{ background: 'rgba(76,140,134,0.18)', color: 'var(--teal)' }}><ClockIcon /></div>
            <div><div className="qa-title">Code refreshes live</div><div className="qa-desc">Updates instantly when you set an amount</div></div>
          </div>
          <div className="qa-card">
            <div className="qa-icon" style={{ background: 'rgba(201,150,44,0.18)', color: 'var(--brass-light)' }}><ShieldIcon /></div>
            <div><div className="qa-title">Safe to share</div><div className="qa-desc">Only your wallet ID is encoded, never card details</div></div>
          </div>
        </div>
      </div>
    </section>
  );
}
