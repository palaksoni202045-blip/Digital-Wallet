import { useEffect, useRef, useState } from 'react';
import WalletCard from './WalletCard.jsx';
import LedgerRow from './LedgerRow.jsx';
import { fmtMoney } from '../utils.js';
import { SendIcon, CardsIcon, ReceiveIcon, SplitIcon } from './Icons.jsx';

export default function Dashboard({ balance, cards, transactions, onNavigate }) {
  const [displayed, setDisplayed] = useState({ int: '0', dec: '00' });
  const prevBalance = useRef(0);

  useEffect(() => {
    const from = prevBalance.current;
    const to = balance;
    const duration = 700;
    const start = performance.now();
    let raf;
    function tick(now) {
      const p = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - p, 3);
      const val = from + (to - from) * eased;
      const [int, dec] = fmtMoney(Math.max(0, val)).split('.');
      setDisplayed({ int, dec });
      if (p < 1) raf = requestAnimationFrame(tick);
      else prevBalance.current = to;
    }
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [balance]);

  const today = new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' });

  return (
    <section className="view active">
      <div className="topbar">
        <div>
          <h1>Good to see you, Aarav</h1>
          <p>{today}</p>
        </div>
        <div className="topbar-actions">
          <button className="btn btn-ghost" onClick={() => onNavigate('transactions')}>View ledger</button>
          <button className="btn btn-brass" onClick={() => onNavigate('send')}>Send money</button>
        </div>
      </div>

      <div className="dash-grid">
        <div className="balance-hero">
          <div className="balance-label">Total balance</div>
          <div className="balance-value">
            ${displayed.int}<span className="cents">.{displayed.dec}</span>
          </div>
          <div className="balance-sub">↑ steady this week</div>
          <div className="hero-actions">
            <button className="btn btn-brass btn-sm" onClick={() => onNavigate('request', 'add')}>+ Add money</button>
            <button className="btn btn-ghost btn-sm" onClick={() => onNavigate('send')}>Send</button>
            <button className="btn btn-ghost btn-sm" onClick={() => onNavigate('request')}>Request</button>
          </div>
        </div>

        <div className="quick-actions">
          <div className="qa-card" onClick={() => onNavigate('send')}>
            <div className="qa-icon" style={{ background: 'rgba(76,140,134,0.18)', color: 'var(--teal)' }}><SendIcon /></div>
            <div><div className="qa-title">Send to a contact</div><div className="qa-desc">Instant transfer, no fees</div></div>
          </div>
          <div className="qa-card" onClick={() => onNavigate('cards')}>
            <div className="qa-icon" style={{ background: 'rgba(201,150,44,0.18)', color: 'var(--brass-light)' }}><CardsIcon /></div>
            <div><div className="qa-title">Manage cards</div><div className="qa-desc">Freeze, add or remove</div></div>
          </div>
          <div className="qa-card" onClick={() => onNavigate('receive')}>
            <div className="qa-icon" style={{ background: 'rgba(217,117,117,0.18)', color: 'var(--coral)' }}><ReceiveIcon /></div>
            <div><div className="qa-title">Get your receive code</div><div className="qa-desc">Show your QR to get paid</div></div>
          </div>
          <div className="qa-card" onClick={() => onNavigate('split')}>
            <div className="qa-icon" style={{ background: 'rgba(107,127,215,0.18)', color: '#6B7FD7' }}><SplitIcon /></div>
            <div><div className="qa-title">Split a bill</div><div className="qa-desc">Divide an expense with friends</div></div>
          </div>
        </div>
      </div>

      <div className="section-head"><h2>Your cards</h2><span className="link" onClick={() => onNavigate('cards')}>Manage all →</span></div>
      <div className="card-row">
        {cards.map((c) => <WalletCard key={c.id} card={c} />)}
      </div>

      <div className="section-head"><h2>Recent activity</h2><span className="link" onClick={() => onNavigate('transactions')}>See all →</span></div>
      <div className="ledger">
        {transactions.slice(0, 5).map((t) => <LedgerRow key={t.id} t={t} />)}
        {transactions.length === 0 && <div className="empty-state">No activity yet.</div>}
      </div>
    </section>
  );
}
