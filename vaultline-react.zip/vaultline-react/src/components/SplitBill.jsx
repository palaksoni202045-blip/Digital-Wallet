import { useState } from 'react';
import { initials, fmtMoney, fmtDate } from '../utils.js';
import { CoveredIcon } from './Icons.jsx';

export default function SplitBill({ contacts, splits, onCreateSplit, onSettleSplit, toast }) {
  const [desc, setDesc] = useState('');
  const [total, setTotal] = useState('');
  const [selected, setSelected] = useState(new Set());
  const [mode, setMode] = useState('equal');
  const [customAmounts, setCustomAmounts] = useState({});

  function toggleContact(id) {
    const next = new Set(selected);
    if (next.has(id)) next.delete(id); else next.add(id);
    setSelected(next);
  }

  const totalNum = parseFloat(total) || 0;
  const ids = Array.from(selected);
  const equalShare = ids.length ? totalNum / ids.length : 0;

  function customFor(id) {
    return customAmounts[id] !== undefined ? customAmounts[id] : equalShare.toFixed(2);
  }

  function submit() {
    if (!totalNum || totalNum <= 0) { toast('Enter a total amount'); return; }
    if (ids.length === 0) { toast('Pick at least one person'); return; }
    const shares = ids.map((id) => ({
      contactId: id,
      amount: mode === 'equal' ? totalNum / ids.length : parseFloat(customFor(id)) || 0,
      settled: false,
    }));
    onCreateSplit(desc.trim() || 'Shared expense', totalNum, shares);
    setDesc('');
    setTotal('');
    setSelected(new Set());
    setCustomAmounts({});
  }

  return (
    <section className="view active">
      <div className="topbar"><div><h1>Split a bill</h1><p>Divide an expense across your contacts and track who&apos;s paid.</p></div></div>
      <div className="dash-grid">
        <div className="panel" style={{ maxWidth: '100%' }}>
          <div className="field">
            <label>What&apos;s this for?</label>
            <input type="text" placeholder="e.g. Dinner at Sundown" value={desc} onChange={(e) => setDesc(e.target.value)} />
          </div>
          <div className="field">
            <label>Total amount</label>
            <div className="amount-input">
              <span>$</span>
              <input type="number" min="0" step="0.01" placeholder="0.00" value={total} onChange={(e) => setTotal(e.target.value)} />
            </div>
          </div>
          <div className="field">
            <label>Split with</label>
            <div className="contact-grid">
              {contacts.map((c) => (
                <div
                  key={c.id}
                  className={`contact-pick${selected.has(c.id) ? ' selected' : ''}`}
                  onClick={() => toggleContact(c.id)}
                >
                  <div className="contact-avatar" style={{ background: c.color }}>{initials(c.name)}</div>
                  <div>{c.name.split(' ')[0]}</div>
                </div>
              ))}
            </div>
          </div>
          <div className="filter-bar" style={{ marginBottom: 14 }}>
            <button className={`chip-filter${mode === 'equal' ? ' active' : ''}`} onClick={() => setMode('equal')}>Split equally</button>
            <button className={`chip-filter${mode === 'custom' ? ' active' : ''}`} onClick={() => setMode('custom')}>Custom amounts</button>
          </div>
          <div>
            {ids.length === 0 && <div className="empty-state" style={{ padding: 24 }}>Pick who&apos;s splitting this with you.</div>}
            {ids.map((id) => {
              const c = contacts.find((x) => x.id === id);
              return (
                <div className="split-share-row" key={id}>
                  <div className="contact-avatar" style={{ background: c.color }}>{initials(c.name)}</div>
                  <div className="share-name">{c.name}</div>
                  <input
                    type="number" min="0" step="0.01"
                    value={customFor(id)}
                    disabled={mode === 'equal'}
                    onChange={(e) => setCustomAmounts({ ...customAmounts, [id]: e.target.value })}
                  />
                </div>
              );
            })}
          </div>
          <button className="btn btn-brass btn-block" style={{ marginTop: 18 }} onClick={submit}>Request from everyone</button>
        </div>
        <div className="quick-actions">
          <div className="qa-card">
            <div className="qa-icon" style={{ background: 'rgba(217,117,117,0.18)', color: 'var(--coral)' }}><CoveredIcon /></div>
            <div><div className="qa-title">Your share is covered</div><div className="qa-desc">You&apos;re automatically excluded from the request total</div></div>
          </div>
        </div>
      </div>

      <div className="section-head"><h2>Split history</h2></div>
      <div className="ledger">
        {splits.length === 0 && <div className="empty-state">No splits yet — create one above.</div>}
        {splits.map((split) => (
          <div key={split.id}>
            <div className="ledger-row" style={{ background: 'var(--ink-elevated)', fontWeight: 600 }}>
              <div className="tx-icon" style={{ background: 'rgba(201,150,44,0.18)', color: 'var(--brass-light)' }}>🧾</div>
              <div className="tx-main">
                <div className="tx-name">{split.desc}</div>
                <div className="tx-meta">{fmtDate(split.date)} · total ${fmtMoney(split.total)}</div>
              </div>
            </div>
            {split.shares.map((s) => {
              const contact = contacts.find((c) => c.id === s.contactId);
              return (
                <div className="ledger-row" style={{ paddingLeft: 52 }} key={s.contactId}>
                  <div className="tx-icon" style={{ width: 26, height: 26, fontSize: 10, background: contact.color + '22', color: contact.color }}>
                    {initials(contact.name)}
                  </div>
                  <div className="tx-main"><div className="tx-name" style={{ fontWeight: 500 }}>{contact.name}</div></div>
                  <div className="tx-leader"></div>
                  <span className={`split-status ${s.settled ? 'settled' : 'pending'}`} style={{ marginRight: 10 }}>
                    {s.settled ? 'Settled' : 'Pending'}
                  </span>
                  <div className="tx-amount" style={{ width: 70, textAlign: 'right' }}>${fmtMoney(s.amount)}</div>
                  {!s.settled && (
                    <button className="btn btn-ghost btn-sm" style={{ marginLeft: 10 }} onClick={() => onSettleSplit(split.id, contact.id)}>
                      Mark paid
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        ))}
      </div>
    </section>
  );
}
