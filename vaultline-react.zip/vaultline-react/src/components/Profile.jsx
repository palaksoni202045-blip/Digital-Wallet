import { WALLET_ID } from '../data/seed.js';

export default function Profile({ onLogout }) {
  return (
    <section className="view active">
      <div className="topbar"><div><h1>Profile</h1><p>Your account details.</p></div></div>
      <div className="panel">
        <div className="field"><label>Full name</label><input type="text" defaultValue="Aarav Kapoor" /></div>
        <div className="field"><label>Email</label><input type="text" defaultValue="aarav.kapoor@email.com" /></div>
        <div className="field"><label>Phone</label><input type="text" defaultValue="+91 98765 43210" /></div>
        <div className="field"><label>Wallet ID</label><input type="text" defaultValue={WALLET_ID} disabled /></div>
        <button
          className="btn btn-ghost btn-block"
          onClick={onLogout}
          style={{ marginTop: 8, color: 'var(--coral)', borderColor: 'rgba(217,117,117,0.3)' }}
        >
          Log out
        </button>
      </div>
    </section>
  );
}
