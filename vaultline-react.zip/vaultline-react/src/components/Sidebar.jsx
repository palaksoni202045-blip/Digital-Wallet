import {
  DashboardIcon, SendIcon, RequestIcon, ReceiveIcon, ScanIcon,
  SplitIcon, CardsIcon, TransactionsIcon, ProfileIcon, LogoutIcon,
} from './Icons.jsx';

const NAV_ITEMS = [
  { view: 'dashboard', label: 'Dashboard', Icon: DashboardIcon },
  { view: 'send', label: 'Send Money', Icon: SendIcon },
  { view: 'request', label: 'Request / Add', Icon: RequestIcon },
  { view: 'receive', label: 'Receive', Icon: ReceiveIcon },
  { view: 'scan', label: 'Scan & Pay', Icon: ScanIcon },
  { view: 'split', label: 'Split Bill', Icon: SplitIcon },
  { view: 'cards', label: 'Cards', Icon: CardsIcon },
  { view: 'transactions', label: 'Transactions', Icon: TransactionsIcon },
];

export default function Sidebar({ activeView, onNavigate, onLogout }) {
  return (
    <nav className="sidebar">
      <div className="brand">
        <div className="brand-mark">V</div>
        <div className="brand-name">Vaultline</div>
      </div>

      {NAV_ITEMS.map(({ view, label, Icon }) => (
        <button
          key={view}
          className={`nav-item${activeView === view ? ' active' : ''}`}
          onClick={() => onNavigate(view)}
        >
          <Icon />
          {label}
        </button>
      ))}

      <div className="nav-divider"></div>
      <button
        className={`nav-item${activeView === 'profile' ? ' active' : ''}`}
        onClick={() => onNavigate('profile')}
      >
        <ProfileIcon />
        Profile
      </button>

      <div className="sidebar-footer">
        <div className="identity">
          <div className="avatar-sm">AK</div>
          <div>
            <div className="name">Aarav Kapoor</div>
            <div className="role">Personal account</div>
          </div>
        </div>
        <button className="logout-btn" onClick={onLogout} title="Log out">
          <LogoutIcon />
        </button>
      </div>
    </nav>
  );
}
