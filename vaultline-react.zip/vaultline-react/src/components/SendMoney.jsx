import { useState } from 'react';
import { initials } from '../utils.js';

export default function SendMoney({ contacts, balance, onSend }) {
  const [selected, setSelected] = useState(null);
  const [amount, setAmount] = useState('');
  const [note, setNote] = useState('');

  function submit() {
    const contact = contacts.find((c) => c.id === selected);
    const amt = parseFloat(amount);
    if (!contact) { onSend.toast('Pick a contact first'); return; }
    if (!amt || amt <= 0) { onSend.toast('Enter a valid amount'); return; }
    if (amt > balance) { onSend.toast('Insufficient balance'); return; }
    onSend.send(contact, amt, note.trim() || 'Sent money');
    setSelected(null);
    setAmount('');
    setNote('');
  }

  return (
    <section className="view active">
      <div className="topbar"><div><h1>Send money</h1><p>Transfers post instantly to a contact&apos;s wallet.</p></div></div>
      <div className="panel">
        <div className="field">
          <label>Choose a contact</label>
          <div className="contact-grid">
            {contacts.map((c) => (
              <div
                key={c.id}
                className={`contact-pick${selected === c.id ? ' selected' : ''}`}
                onClick={() => setSelected(c.id)}
              >
                <div className="contact-avatar" style={{ background: c.color }}>{initials(c.name)}</div>
                <div>{c.name.split(' ')[0]}</div>
              </div>
            ))}
          </div>
        </div>
        <div className="field">
          <label>Amount</label>
          <div className="amount-input">
            <span>$</span>
            <input type="number" min="0" step="0.01" placeholder="0.00" value={amount} onChange={(e) => setAmount(e.target.value)} />
          </div>
        </div>
        <div className="field">
          <label>Note (optional)</label>
          <input type="text" placeholder="What's it for?" value={note} onChange={(e) => setNote(e.target.value)} />
        </div>
        <button className="btn btn-brass btn-block" onClick={submit}>Send money</button>
      </div>
    </section>
  );
}
