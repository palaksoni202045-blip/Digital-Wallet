export const WALLET_ID = 'VL-8842-AK';

export const initialContacts = [
  { id: 'c1', name: 'Meera Shah', color: '#4C8C86' },
  { id: 'c2', name: 'Rohan Iyer', color: '#C9962C' },
  { id: 'c3', name: 'Priya Nair', color: '#D97575' },
  { id: 'c4', name: 'Dev Malhotra', color: '#6B7FD7' },
  { id: 'c5', name: 'Zara Khan', color: '#B27ED9' },
  { id: 'c6', name: 'Kabir Rao', color: '#4C8C86' },
  { id: 'c7', name: 'Anika Sen', color: '#C9962C' },
  { id: 'c8', name: 'Yusuf Ali', color: '#D97575' },
];

export const initialCards = [
  { id: 'card1', issuer: 'Vaultline Metal', last4: '4821', holder: 'AARAV KAPOOR', expiry: '09/28', frozen: false, gradient: 'linear-gradient(135deg,#e3b85c,#c9962c 55%,#8a6416)' },
  { id: 'card2', issuer: 'Vaultline Slate', last4: '1190', holder: 'AARAV KAPOOR', expiry: '02/27', frozen: false, gradient: 'linear-gradient(135deg,#5c6b7c,#333c47 65%)' },
];

export const merchantIcons = ['🛒', '☕', '✈️', '🏠', '🎬', '📱', '🍽️', '⚡'];

export function seedTransactions() {
  const seed = [
    { name: 'Meera Shah', type: 'in', amount: 120.0, note: 'Split dinner' },
    { name: 'Grocery Mart', type: 'out', amount: 64.32, note: 'Weekly groceries' },
    { name: 'Top-up · Vaultline Metal', type: 'in', amount: 500.0, note: 'Card top-up' },
    { name: 'Rohan Iyer', type: 'out', amount: 75.0, note: 'Movie tickets' },
    { name: 'Cloudline Hosting', type: 'out', amount: 12.99, note: 'Subscription' },
    { name: 'Priya Nair', type: 'in', amount: 220.0, note: 'Freelance payment' },
    { name: 'City Transit', type: 'out', amount: 3.5, note: 'Metro card' },
    { name: 'Dev Malhotra', type: 'out', amount: 45.0, note: 'Concert split' },
  ];
  const now = Date.now();
  return seed.map((t, i) => ({
    id: 'tx' + i,
    ...t,
    icon: merchantIcons[i % merchantIcons.length],
    date: new Date(now - i * 1000 * 60 * 60 * 20),
  }));
}

export const newCardBrands = [
  { issuer: 'Vaultline Onyx', gradient: 'linear-gradient(135deg,#3a3f4d,#181a22 65%)' },
  { issuer: 'Vaultline Copper', gradient: 'linear-gradient(135deg,#d98b5c,#a35a2e 60%)' },
  { issuer: 'Vaultline Frost', gradient: 'linear-gradient(135deg,#9fb4c7,#5c7286 65%)' },
];
